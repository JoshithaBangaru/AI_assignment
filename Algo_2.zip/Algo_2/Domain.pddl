(define (domain mars-rover)
  (:requirements :strips :typing)
  (:types location rock bay)

  (:predicates
    (rover-at ?l - location)
    (connected ?from ?to - location)   ; directed edge
    (rock-at ?r - rock ?l - location)
    (soft ?r - rock)
    (hard ?r - rock)
    (drill-at ?l - location)
    (has-drill)
    (bay-empty ?b - bay)
    (in-bay ?r - rock ?b - bay)
  )

  (:action move
    :parameters (?from ?to - location)
    :precondition (and (rover-at ?from) (connected ?from ?to))
    :effect (and (rover-at ?to) (not (rover-at ?from))))

  (:action pick-drill
    :parameters (?l - location)
    :precondition (and (rover-at ?l) (drill-at ?l))
    :effect (and (has-drill) (not (drill-at ?l))))

  (:action collect-soft
    :parameters (?r - rock ?l - location ?b - bay)
    :precondition (and (rover-at ?l) (rock-at ?r ?l) (soft ?r) (bay-empty ?b))
    :effect (and (in-bay ?r ?b) (not (rock-at ?r ?l)) (not (bay-empty ?b))))

  (:action collect-hard
    :parameters (?r - rock ?l - location ?b - bay)
    :precondition (and (rover-at ?l) (rock-at ?r ?l) (hard ?r) (has-drill) (bay-empty ?b))
    :effect (and (in-bay ?r ?b) (not (rock-at ?r ?l)) (not (bay-empty ?b))))

  (:action deposit
    :parameters (?r - rock ?l - location ?b - bay)
    :precondition (and (rover-at ?l) (in-bay ?r ?b))
    :effect (and (rock-at ?r ?l) (bay-empty ?b) (not (in-bay ?r ?b))))
)
