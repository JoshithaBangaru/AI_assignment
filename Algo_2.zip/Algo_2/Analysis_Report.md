# Mars Rover Sample Collection – Analysis Report

## Method
- `Domain.pddl` (`:strips :typing`): types `location rock bay`; actions `move`, `pick-drill`, `collect-soft`, `collect-hard` (needs `has-drill`), `deposit`. The one-way route is encoded by directed `connected` facts (only `sitec -> sited` exists, no `sited -> sitec`). Two-way routes have both directions.
- Goal: every rock `rock-at ... base`, both bays empty, `rover-at base`.
- **Planner note:** no PDDL planner was installed in my sandbox, so the searches were run with my own Python implementations of the same algorithms on the grounded domain (`solve.py`, `fast.py`): greedy best-first search with the h_add heuristic (satisficing) and A* with an admissible heuristic (optimal; breadth-first used as a cross-check on Scenario 1). Statistics are therefore from these implementations, not Fast Downward. With Fast Downward you would run e.g. `fast-downward.py Domain.pddl Problem.pddl --search "eager_greedy([add()])"` and `--search "astar(lmcut())"`.
- All plans were checked with an independent step-by-step simulator (`validate.py`); each step's preconditions hold and the goal is satisfied.

## Results
| Scenario | Configuration | Plan length (= #actions) | States expanded | States generated | Time |
|---|---|---|---|---|---|
| Original | GBFS (h_add) | 34 | 77 | 221 | 0.17 s |
| Original | A* (admissible) | **25** | 1,476 | 3,422 | 0.015 s |
| Original | BFS (cross-check) | 25 | 332,568 | 337,074 | 7.1 s |
| Extended | GBFS (h_add) | 61 | 721 | 1,652 | 1.4 s |
| Extended | A* (admissible) | **40** | 612,873 | 1,125,684 | 13.3 s |

All actions have unit cost, so plan length equals cost and total number of actions. Full action sequences are in `planner_output/`.

## Goal verification (final states)
Original, optimal plan: `rover-at base`; `rock1..rock5` all `rock-at ... base`; `bay-empty bay1`, `bay-empty bay2`; `has-drill` (the drill is kept, as specified). Same final state for the GBFS plan. Extended plans: the same, with `rock1..rock7` at base. Goal satisfied in all four.

## Task 6 – Analysis
**1. Plan lengths.** Original: 34 (GBFS) vs 25 (optimal), 9 extra actions. Extended: 61 vs 40, 21 extra. The greedy search follows the heuristic and commits to the first promising branch. It carries one rock at a time (its plans only ever use `bay1`), so it makes many extra round trips to Base, and repeats the long trek to SiteE/SiteF. The optimal search proves no shorter plan exists and batches work using both bays. The gap grows in the extended scenario, with more rocks and a longer detour, because every unnecessary round trip is more expensive. The price of optimality is search effort: 1,476 vs 77 expansions, and 612,873 vs 721 in the extended case.

**2. Optimal plan, bays and drill (original).** First trip: go Base→SiteB, collect Rock2 (bay1), go to SiteD, collect Rock4 (bay2), return D→B→Base and deposit both. Second trip: Base→A→C→E; the drill is picked up at **SiteE (action 11)**, only when it is first needed, since the soft rocks needed no drill. Then SiteF: Rock5 (hard) into bay1, back via E to SiteC: Rock3 (hard) into bay2. Both bays are full on the way back to Base; Rock3 is deposited (freeing bay2), the rover steps to SiteA for Rock1 (bay2), returns to Base and deposits Rock1 and Rock5. Both bays are used at full capacity on each of the two main trips and everything is delivered with the rover finishing at Base. The one-way route is not needed here.

**3. Extended scenario (optimal, 40 actions).** With Base↔SiteB closed, SiteB is reachable only through SiteD (SiteB's remaining link is SiteB↔SiteD), and SiteD only from SiteC or SiteE. The plan goes Base→A→C, then uses the **one-way slope C→D** (forward direction, downhill) to reach SiteD (Rock4, bay1), then D→B for SiteB (Rock2, bay2). It returns B→D→E (picking up the drill at SiteE), then E→C→A→Base. The slope is used exactly once, in its permitted direction. The rover never needs D→C, which is impossible, and instead comes back via SiteE. Later trips: Rock5 and Rock7 (both hard, at SiteF) are collected together (bays 1 and 2); then Rock6 (SiteE, soft, bay1) and Rock3 (SiteC, bay2) on the next trip; finally Rock1 at SiteA.
