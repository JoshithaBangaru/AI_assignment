% royal_archive_access.pl

% Step 1: FOL representation
% Predicates: archivist/1, trusted/1, verifies/2, inspects/2,
% hidden_mark/2, has_access/2, sealed/1, stored_in_royal_archive/1,
% permitted_inspect/2. Constants: mira, scroll_7.

% Step 2: Negated goal
% Goal: trusted(mira). Negated goal: not trusted(mira).

% Step 3: Remove implications
% (archivist(X) AND verifies(X,R)) -> trusted(X)
% (trusted(X) AND has_access(X,R) AND sealed(R)) -> permitted_inspect(X,R)
% (inspects(X,R) AND hidden_mark(X,R)) -> verifies(X,R)
% stored_in_royal_archive(R) -> sealed(R)

% Step 4: Negation movement
% All negations are applied to atomic predicates after implication removal.

% Step 5: Standardization apart
% Variables in each rule are local and standardized apart.

% Step 6: Skolemization
% No existential variables occur; no Skolem terms are needed.

% Step 7: CNF clauses
cnf(rule1, [neg(archivist(X)), neg(verifies(X,R)), pos(trusted(X))]).
cnf(rule2, [neg(trusted(X)), neg(has_access(X,R)), neg(sealed(R)), pos(permitted_inspect(X,R))]).
cnf(rule3, [neg(inspects(X,R)), neg(hidden_mark(X,R)), pos(verifies(X,R))]).
cnf(rule4, [neg(stored_in_royal_archive(R)), pos(sealed(R))]).

cnf(fact1, [pos(stored_in_royal_archive(scroll_7))]).
cnf(fact2, [pos(has_access(mira, scroll_7))]).
cnf(fact3, [pos(inspects(mira, scroll_7))]).
cnf(fact4, [pos(hidden_mark(mira, scroll_7))]).
cnf(fact5, [pos(archivist(mira))]).
cnf(negated_goal, [neg(trusted(mira))]).

% Step 8: Resolution
resolve(C1, C2, Resolvent) :-
    select(pos(A), C1, Rest1),
    select(neg(B), C2, Rest2),
    A = B,
    append(Rest1, Rest2, Combined),
    sort(Combined, Resolvent).
resolve(C1, C2, Resolvent) :-
    select(neg(A), C1, Rest1),
    select(pos(B), C2, Rest2),
    A = B,
    append(Rest1, Rest2, Combined),
    sort(Combined, Resolvent).

prove_mira_trusted :-
    writeln('ROYAL ARCHIVE: RESOLUTION REFUTATION'),
    cnf(rule1, C1),
    cnf(fact5, F1),
    resolve(C1, F1, R1),
    format('Step 1: Resolve rule1 with archivist(mira): ~w~n', [R1]),
    cnf(negated_goal, NG),
    resolve(R1, NG, R2),
    format('Step 2: Resolve Step 1 with not trusted(mira): ~w~n', [R2]),
    cnf(rule3, C3),
    cnf(fact3, F2),
    resolve(C3, F2, R3),
    format('Step 3: Resolve rule3 with inspects(mira,scroll_7): ~w~n', [R3]),
    resolve(R3, R2, R4),
    format('Step 4: Resolve Step 3 with Step 2: ~w~n', [R4]),
    cnf(fact4, F3),
    resolve(R4, F3, R5),
    format('Step 5: Resolve Step 4 with hidden_mark(mira,scroll_7): ~w~n', [R5]),
    ( R5 == [] ->
        writeln('EMPTY CLAUSE [] DERIVED. CONTRADICTION FOUND.'),
        writeln('Therefore, trusted(mira) is proved.')
    ;
        writeln('Proof failed: empty clause was not derived.')
    ).

show_cnf :-
    forall(cnf(Name, Clause),
           (write(Name), write(': '), writeln(Clause))).
